<!DOCTYPE HTML>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>NGPF-BankSimulator</title>

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,700i" rel="stylesheet">

  <!-- fontawesome -->
  <link rel="stylesheet" href="css/font-awesome.css">

  <!-- select2 style -->
  <link href="css/select2.css" rel="stylesheet" type="text/css" />

  <!-- bootstrap style -->
  <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />

  <!-- main style -->
  <link href="css/mainstyle.css" rel="stylesheet" type="text/css" />

  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" type="text/css">
  <link href="administrator/plugins/iCheck/minimal/orange.css" rel="stylesheet" type="text/css" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.0.9/sweetalert2.css" rel="stylesheet" type="text/css" />
<!--[if lt IE 9]>
<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
<![endif]-->

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script src="js/modernizr.custom.97554.js"></script>
<!--[if (gte IE 6)&(lte IE 8)]>
  <script type="text/javascript" src="js/selectivizr.js"></script>
  <noscript><link rel="stylesheet" href="[fallback css]" /></noscript>
  <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<![endif]-->

</head>

<body>
  <div class="bg clearfix">
    <!-- start of header -->
    <header>
      <div class="container">
       <div class="row">
        <div class="col-md-3 col-sm-3 col-xs-12">
         <div class="logo">
          <a href="index.php"><img src="images/NGPF-logo.png" alt=""></a>
        </div>
      </div>
      <div class="col-md-9 col-sm-9 col-xs-12">
       <a href="register.php"><div class="reg">
         <img src="images/register-icon.png"> Create a free account
       </div></a>
     </div>
     <div class="col-md-12 col-sm-12 col-xs-12">
       <hr>
     </div>
   </div>
 </div>
</header>
<!-- end of header -->
<!-- welcome section -->
<div class="welcome text_entry clearfix">
  <div class="container">
   <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
             <div class='alert alert-danger alert-dismissable'>
		<button aria-hidden='true' data-dismiss='alert' class='close' type='button'>×</button>
		<h4><i class='icon fa fa-ban'></i> Alert!</h4>Error: Please login to access this page!</div>       <h1><span>Welcome to</span>OnlineBank Sim</h1>
      <p>This Online Banking Simulation allows you to see what it is like to manage your very own online bank account. In the process, you will be able to manage this account when various situations arise, make all of the online transactions you would on a real account, and see the consequences of your actions- good or bad! With OnlineBank Sim you can:</p>

      <ul>
        <li>Look at the account activity for both checking and savings</li>
        <li>Look at monthly bank statements.</li>
        <li>Pay bills, transfer funds between accounts, and make check deposits online.</li>
        <li>and more!</li>
      </ul>

      <p>You will be able to do most of what you can do with a real account with one big difference: you will not be using real money so you can't really fail! This simulation also allows you to change the time frame so that when you turn the clock forward or backward, you can see the result. To get started:</p>

      <div class="log-in clearfix">
        <h3>Already have an OnlineBank Sim Account?  <span>Login Here</span></h3>
        <form role="form" name="login_form" id="login_form" action="login_process.php" method="post">
         <div class="input-box">
           <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon"><i class="fa fa-user" aria-hidden="true"></i></span>
              <input type="text" class="form-control" id="member_username" name="member_username" placeholder="USERNAME" required>
            </div>
            <span class="erroruser with-errors"></span>
          </div>
          <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon"><i class="fa fa-lock" aria-hidden="true"></i></span>
              <input type="password" class="form-control" name="member_password" id="member_password" placeholder="PASSWORD" required>
            </div>
            <span class="errorpass with-errors"></span>
          </div>
          <span class="errormess with-errors"></span>
          <span class="forgot" data-toggle="modal" data-target="#recoverpassword">Forgot Password?</span>
        </div>
        <div class="form-group submit_box">
          <button type="submit" id="submit_login" class="btn" name="submit_login">Login</button>
        </div>
      </form>
      <small>* This account is not the same as an NGPF teacher account. To create an online banking simulation account click on the button at the top right of your screen</small>
    </div>

  </div>
</div>
</div>
</div>
<!-- welcome section -->
</div>
<!-- how it works -->
<div class="works clearfix">
  <div class="container">
   <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
     <div class="section-title">
       <h2>how it works</h2>
     </div>
   </div>

   <div class="col-md-3 col-sm-6 col-xs-12 same_height">
    <div class="work-icon">
     <div class="inner"><img src="images/work-icon01.png" alt=""></div>
   </div>
   <!--<h2>Lorem ipsum dolor</h2>-->
   <p>Many people have turned to online banking to manage their checking and savings accounts from their computer.</p>
 </div>

 <div class="col-md-3 col-sm-6 col-xs-12 same_height">
  <div class="work-icon">
   <div class="inner yellow_bg"><img src="images/work-icon02.png" alt=""></div>
 </div>
 <!--<h2>Lorem ipsum dolor</h2>-->
 <p>Online banking allows you to make transfers, deposit checks, check your account activity without having to visit the bank. You will be able to experience an account without having to play around with your own money.</p>
</div>

<div class="col-md-3 col-sm-6 col-xs-12 same_height">
  <div class="work-icon">
   <div class="inner orange_bg"><img src="images/work-icon03.png" alt=""></div>
 </div>
 <!--<h2>Lorem ipsum dolor</h2>-->
 <p>Instead of writing checks and balancing your checkbook, you can review your statements online, pay bills or transfer money with the touch of a button.</p>
</div>

<div class="col-md-3 col-sm-6 col-xs-12 same_height">
  <div class="work-icon">
   <div class="inner blue_bg"><img src="images/work-icon04.png" alt=""></div>
 </div>
 <!--<h2>Lorem ipsum dolor</h2>-->
 <p>Using our simulation date feature, you will be able to track when your money comes and goes over time to better understand how you will manage your own online banking account in the future. </p>
</div>
</div>
</div>
</div>

<!-- reset password modal -->
<div id="recoverpassword" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Reset your password</h4>
      </div>
      <div class="modal-body">
        <form action="index.php" method="get" class="" id="member_password_reset_form" role="form">
          <div class="form-group clearfix">
            <div class="input-group">
              <span class="input-group-addon"><i class="fa fa-user" aria-hidden="true"></i></span>
              <input type="text" class="form-control" name="member_username1" id="member_username1" placeholder="Username" data-rule-required="true" onfocusout="userquesBlock()">
            </div>
            <div class="help-block with-errors"></div>
          </div>
          <div class="clearfix" id="userquesBlock">
            <div class="col-xs-12 col-sm-12">
              <div class="form-group clearfix">
                <label>What is your name ?</label>
                <div class="input-group">
                  <input type="text" name="member_security_answer1" class="form-control" id="" placeholder="Answer 1" data-error="That answer is invalid" required>
                </div>
                <div class="help-block with-errors"></div>
              </div>
            </div>
            <div class="col-xs-12 col-sm-12">
              <div class="form-group clearfix">
                <label>What is your DOB ?</label>
                <div class="input-group">
                  <input type="text" name="member_security_answer2" class="form-control" id="" placeholder="Answer 2" data-error="That answer is invalid" required>
                </div>
                <div class="help-block with-errors"></div>
              </div>
            </div>
          </div>
          <div class="form-group">
            <button type="submit" name="password_reset" class="btn" id="password_reset" value="Submit">Submit</button>
          </div>
          <div id="error_message" class="ajax_response"></div>
          <div id="success_message" class="ajax_response alert-success"></div>
        </form>
      </div>
    </div>

  </div>
</div>
<!-- how it works -->

<!-- footer -->
<footer class="clearfix">
  <div class="container">
   <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
     &copy; Copyright 2017 . All rights reserved.
   </div>
 </div>
</div>
</footer>
<!-- footer -->

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.3.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js/bootstrap.min.js"></script>
<!-- <script src="js/select2.min.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js" integrity="sha256-FA14tBI8v+/1BtcH9XtJpcNbComBEpdawUZA6BPXRVw=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/additional-methods.min.js"></script>
<script src="js/jquery.matchHeight.js"></script>
<script src="js/customjs.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.0.9/sweetalert2.js"></script>
<script src="administrator/plugins/iCheck/icheck.min.js" type="text/javascript"></script>
<script type="text/javascript">
  $(function () {
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-orange',
      radioClass: 'iradio_minimal-orange'
    });
  });
</script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112660170-1"></script>
<script>
 window.dataLayer = window.dataLayer || [];
 function gtag(){dataLayer.push(arguments);}
 gtag('js', new Date());

 gtag('config', 'UA-112660170-1');
</script>
</body>
</html>