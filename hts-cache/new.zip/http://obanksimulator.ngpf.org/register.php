<!DOCTYPE HTML>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>NGPF-BankSimulator</title>

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,700i" rel="stylesheet">

  <!-- fontawesome -->
  <link rel="stylesheet" href="css/font-awesome.css">

  <!-- select2 style -->
  <link href="css/select2.css" rel="stylesheet" type="text/css" />

  <!-- bootstrap style -->
  <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />

  <!-- main style -->
  <link href="css/mainstyle.css" rel="stylesheet" type="text/css" />

  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" type="text/css">
  <link href="administrator/plugins/iCheck/minimal/orange.css" rel="stylesheet" type="text/css" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.0.9/sweetalert2.css" rel="stylesheet" type="text/css" />
<!--[if lt IE 9]>
<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
<![endif]-->

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script src="js/modernizr.custom.97554.js"></script>
<!--[if (gte IE 6)&(lte IE 8)]>
  <script type="text/javascript" src="js/selectivizr.js"></script>
  <noscript><link rel="stylesheet" href="[fallback css]" /></noscript>
  <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<![endif]-->

</head>

<body>
  <div class="bg clearfix">
    <!-- start of header -->
    <header>
      <div class="container">
       <div class="row">
        <div class="col-md-3 col-sm-3 col-xs-12">
         <div class="logo">
          <a href="index.php"><img src="images/NGPF-logo.png" alt=""></a>
        </div>
      </div>
      <div class="col-md-9 col-sm-9 col-xs-12">
       <a href="register.php"><div class="reg">
         <img src="images/register-icon.png"> Create a free account
       </div></a>
     </div>
     <div class="col-md-12 col-sm-12 col-xs-12">
       <hr>
     </div>
   </div>
 </div>
</header>
<!-- end of header -->
<!-- welcome section -->
<div class="welcome text_entry clearfix">
  <div class="container">
   <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
     <h1><span>Welcome to</span>OnlineBank Sim</h1>
     <p>Please fill in the form below to register for your OnlineBank Sim account. Make sure you choose a username and password you can remember. There are some fields that have been filled out for you for privacy purposes (ex: address). If you do not want to include your full name, you can input a nickname or fake name for the simulation. Just make sure you like it! You will also have the chance to set up some potential alerts and decide how you want to split up your paycheck into checking/savings. You can always change your choices, but remember all of your financial decisions have consequences!</p>

     <div class="form-block">
            <form action="/register.php" class="" method="post" enctype="multipart/form-data" name="member_form" id="member_form" role="form">

        <div class="form-group clearfix">
          <label>username</label>
          <div class="form-cover">
            <input type="text" class="form-control" id="member_username" name="member_username" data-rule-required="true">

          </div>
        </div>

        <div class="form-group clearfix">
          <label>password</label>
          <div class="form-cover">
            <input type="password" class="form-control" id="member_password" name="member_password" data-rule-required="true">

          </div>
        </div>

        <div class="form-group clearfix">
          <label>First name</label>
          <div class="form-cover">
            <input type="text" class="form-control" id="member_first_name" name="member_first_name" data-rule-required="true">

          </div>
        </div>
        <div class="form-group clearfix">
          <label>address</label>
          <div class="form-cover">
            <input type="text" class="form-control" value="845 Austyn Parks" id="member_address" name="member_address" readonly>

          </div>
        </div>

        <div class="form-group clearfix">
          <label>City</label>
          <div class="form-cover">
            <input type="text" class="form-control" value="Konopelskiland" id="member_city" name="member_city" readonly>

          </div>
        </div>

        <div class="form-group clearfix">
          <label>state</label>
          <div class="form-cover">
            <input type="text" class="form-control" value="Montana" id="member_state" name="member_state" readonly>

          </div>
        </div>

        <div class="form-group clearfix">
          <label>Zip</label>
          <div class="form-cover">
            <input type="text" value="56976-7988" class="form-control" id="member_zip" name="member_zip" readonly>

          </div>
        </div>
        <div class="form-group clearfix">
          <label>Question 1</label>
          <div class="form-cover">
            <select name="member_security_question_id1" id="member_security_question_id1" class="form-control" data-rule-required="true">
              <option value="" selected>Please Select</option>
                             <option value="1" >What was your childhood nickname?</option>
                              <option value="2" >What is the name of your favorite childhood friend?</option>
                              <option value="3" >In what city or town did your mother and father meet?</option>
                              <option value="4" >What is your favorite team?</option>
                              <option value="5" >What was the name of the hospital where you were born?</option>
                              <option value="6" >What was your favorite food as a child?</option>
                              <option value="7" >What is your favorite movie?</option>
                              <option value="8" >Who is your childhood sports hero?</option>
                              <option value="9" >What school did you attend for sixth grade?</option>
                              <option value="10" >In what town was your first job?</option>
                          </select>
           <span class="disclaimer-txt">We will not share your information with any third party.</span>
         </div>
       </div>

       <div class="form-group clearfix">
        <label>Answer 1</label>
        <div class="form-cover">
          <input type="text" class="form-control" id="member_security_question_answer1" name="member_security_question_answer1" data-rule-required="true">

        </div>
      </div>

      <div class="form-group clearfix">
        <label>Question 2</label>
        <div class="form-cover">
          <select name="member_security_question_id2" id="member_security_question_id2" class="form-control" data-rule-required="true">
            <option value="" selected>Please Select</option>
                         <option value="1" >What was your childhood nickname?</option>
                          <option value="2" >What is the name of your favorite childhood friend?</option>
                          <option value="3" >In what city or town did your mother and father meet?</option>
                          <option value="4" >What is your favorite team?</option>
                          <option value="5" >What was the name of the hospital where you were born?</option>
                          <option value="6" >What was your favorite food as a child?</option>
                          <option value="7" >What is your favorite movie?</option>
                          <option value="8" >Who is your childhood sports hero?</option>
                          <option value="9" >What school did you attend for sixth grade?</option>
                          <option value="10" >In what town was your first job?</option>
                      </select>
         <span class="disclaimer-txt">We will not share your information with any third party.</span>
       </div>
     </div>

     <div class="form-group clearfix">
      <label>Answer 2</label>
      <div class="form-cover">
        <input type="text" class="form-control" id="member_security_question_answer2" name="member_security_question_answer2" data-rule-required="true">

      </div>
    </div>
    <div class="form-group">
      <label>Alert</label>
      <div class="form-cover">
                 <input type="hidden" name="alert_id[]" value="1">
         <div class="clearfix row">
          <div class="col-sm-6 clearfix">
            <input type="hidden" name="member_below_alert[]" id="member_below_alert_id_0" value="">
            <input type="checkbox" class="minimal" id="member_below_alert_0" >
           IF THE CHECKING OR SAVINGS ACCOUNT FALLS BELOW         </div>
         <div class="col-sm-6 clearfix">
          <div class="clearfix form-group">
            <input type="text" class="form-control" placeholder="Enter ..." name="member_below_alert_text_0" id="member_below_alert_text_0" value=""
            disabled />
          </div>
        </div>
      </div>
               <input type="hidden" name="alert_id[]" value="2">
         <div class="clearfix row">
          <div class="col-sm-6 clearfix">
            <input type="hidden" name="member_below_alert[]" id="member_below_alert_id_1" value="">
            <input type="checkbox" class="minimal" id="member_below_alert_1" >
           IF THERE IS A SAVINGS/CHECKING ACCOUNT WITHDRAWAL GREATER THAN         </div>
         <div class="col-sm-6 clearfix">
          <div class="clearfix form-group">
            <input type="text" class="form-control" placeholder="Enter ..." name="member_below_alert_text_1" id="member_below_alert_text_1" value=""
            disabled />
          </div>
        </div>
      </div>
               <input type="hidden" name="alert_id[]" value="3">
         <div class="clearfix row">
          <div class="col-sm-6 clearfix">
            <input type="hidden" name="member_below_alert[]" id="member_below_alert_id_2" value="">
            <input type="checkbox" class="minimal" id="member_below_alert_2" >
           IF THE CHECKING OR SAVINGS ACCOUNT TRANSACTION GREATER THAN         </div>
         <div class="col-sm-6 clearfix">
          <div class="clearfix form-group">
            <input type="text" class="form-control" placeholder="Enter ..." name="member_below_alert_text_2" id="member_below_alert_text_2" value=""
            disabled />
          </div>
        </div>
      </div>
               <input type="hidden" name="alert_id[]" value="4">
         <div class="clearfix row">
          <div class="col-sm-6 clearfix">
            <input type="hidden" name="member_below_alert[]" id="member_below_alert_id_3" value="">
            <input type="checkbox" class="minimal" id="member_below_alert_3" >
           IF BILL PAYS FROM CHECKING ACCOUNT GREATER THAN         </div>
         <div class="col-sm-6 clearfix">
          <div class="clearfix form-group">
            <input type="text" class="form-control" placeholder="Enter ..." name="member_below_alert_text_3" id="member_below_alert_text_3" value=""
            disabled />
          </div>
        </div>
      </div>
               <input type="hidden" name="alert_id[]" value="5">
         <div class="clearfix row">
          <div class="col-sm-6 clearfix">
            <input type="hidden" name="member_below_alert[]" id="member_below_alert_id_4" value="">
            <input type="checkbox" class="minimal" id="member_below_alert_4" >
           IF THE CHECKING OR SAVING ACCOUNT DEPOSIT GREATER THAN         </div>
         <div class="col-sm-6 clearfix">
          <div class="clearfix form-group">
            <input type="text" class="form-control" placeholder="Enter ..." name="member_below_alert_text_4" id="member_below_alert_text_4" value=""
            disabled />
          </div>
        </div>
      </div>
          </div>
  </div>


  <div class="form-group">
   <button type="reset" class="btn"><i class="fa fa-times" aria-hidden="true"></i> cancel</button>
   <button type="submit" class="btn" name="submit" value="Submit"><i class="fa fa-paper-plane-o" aria-hidden="true"></i> submit</button>
 </div>
</form>
</div>



</div>
</div>
</div>
</div>
<!-- welcome section -->
</div>

<!-- footer -->
<footer class="clearfix">
  <div class="container">
   <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
     &copy; Copyright 2017 . All rights reserved.
   </div>
 </div>
</div>
</footer>
<!-- footer -->

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.3.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js/bootstrap.min.js"></script>
<!-- <script src="js/select2.min.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js" integrity="sha256-FA14tBI8v+/1BtcH9XtJpcNbComBEpdawUZA6BPXRVw=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/additional-methods.min.js"></script>
<script src="js/jquery.matchHeight.js"></script>
<script src="js/customjs.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.0.9/sweetalert2.js"></script>
<script src="administrator/plugins/iCheck/icheck.min.js" type="text/javascript"></script>
<script type="text/javascript">
  $(function () {
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-orange',
      radioClass: 'iradio_minimal-orange'
    });
  });
</script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112660170-1"></script>
<script>
 window.dataLayer = window.dataLayer || [];
 function gtag(){dataLayer.push(arguments);}
 gtag('js', new Date());

 gtag('config', 'UA-112660170-1');
</script>
</body>
</html>